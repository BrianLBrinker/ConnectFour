(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "+Xw4":
/*!******************************************************************!*\
  !*** ./src/app/components/connect-four/board/board.component.ts ***!
  \******************************************************************/
/*! exports provided: BoardComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BoardComponent", function() { return BoardComponent; });
/* harmony import */ var src_app_models_player__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/models/player */ "NAel");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");



function BoardComponent_li_2_li_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "li", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](1, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} }
const _c0 = function (a0) { return { "bottom.px": a0 }; };
function BoardComponent_li_2_li_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](0, "li", 5);
} if (rf & 2) {
    const r_r8 = ctx.index;
    const c_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]().index;
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngClass", ctx_r4.getClassFrom(ctx_r4.tokenGrid[r_r8][c_r2]))("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction1"](2, _c0, ctx_r4.cellMargin + ctx_r4.cellSize * (ctx_r4.rows.length - 1 - r_r8)));
} }
function BoardComponent_li_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "li");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "ul");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](2, BoardComponent_li_2_li_2_Template, 2, 0, "li", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](3, BoardComponent_li_2_li_3_Template, 1, 4, "li", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx_r0.rows);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx_r0.rows);
} }
class BoardComponent {
    constructor() {
        this.cellSize = 70;
        this.cellMargin = 10;
    }
    ngOnInit() {
        this.rows = new Array(this.boardHeight);
        this.columns = new Array(this.boardWidth);
    }
    getClassFrom(token) {
        switch (token) {
            case src_app_models_player__WEBPACK_IMPORTED_MODULE_0__["TokenVals"].unclaimed:
                return "token ";
            case src_app_models_player__WEBPACK_IMPORTED_MODULE_0__["TokenVals"].player1:
                return "token player1";
            case src_app_models_player__WEBPACK_IMPORTED_MODULE_0__["TokenVals"].player2:
                return "token player2";
            default:
                return "token ";
        }
    }
}
BoardComponent.ɵfac = function BoardComponent_Factory(t) { return new (t || BoardComponent)(); };
BoardComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: BoardComponent, selectors: [["app-board"]], inputs: { boardWidth: "boardWidth", boardHeight: "boardHeight", tokenGrid: "tokenGrid" }, decls: 3, vars: 1, consts: [[4, "ngFor", "ngForOf"], ["class", "board", 4, "ngFor", "ngForOf"], [3, "ngClass", "ngStyle", 4, "ngFor", "ngForOf"], [1, "board"], [1, "cell"], [3, "ngClass", "ngStyle"]], template: function BoardComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "section");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "ul");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](2, BoardComponent_li_2_Template, 4, 2, "li", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx.columns);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["NgForOf"], _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgClass"], _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgStyle"]], styles: ["section[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%] {\n  list-style-type: none;\n  list-style-position: inside;\n  margin: 0;\n  padding: 0;\n  display: flex;\n}\nsection[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  position: relative;\n}\nsection[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   li.board[_ngcontent-%COMP%] {\n  position: relative;\n  z-index: 1;\n}\nsection[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   li.board[_ngcontent-%COMP%]   .cell[_ngcontent-%COMP%] {\n  position: relative;\n  width: 70px;\n  height: 70px;\n  margin: 0;\n  text-align: center;\n  overflow: hidden;\n}\nsection[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   li.board[_ngcontent-%COMP%]   .cell[_ngcontent-%COMP%]:after {\n  content: \"\";\n  position: absolute;\n  left: 10px;\n  top: 10px;\n  border-radius: 50%;\n  width: 50px;\n  height: 50px;\n  box-shadow: 0px 0px 0px 70px #003b6f;\n}\nsection[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   li.token[_ngcontent-%COMP%] {\n  position: absolute;\n  z-index: 0;\n  left: 10px;\n  width: 50px;\n  height: 50px;\n}\nsection[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   li.token.player1[_ngcontent-%COMP%] {\n  background-color: #ff0;\n}\nsection[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   li.token.player2[_ngcontent-%COMP%] {\n  background-color: #f00;\n}\nsection[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   li.token.win[_ngcontent-%COMP%]:after {\n  background-color: #000;\n  content: \"\";\n  position: absolute;\n  left: 17px;\n  top: 17px;\n  border-radius: 50%;\n  width: 16px;\n  height: 16px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL2JvYXJkLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNFO0VBQ0UscUJBQUE7RUFDQSwyQkFBQTtFQUNBLFNBQUE7RUFDQSxVQUFBO0VBQ0EsYUFBQTtBQUFKO0FBRUk7RUFDRSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSxrQkFBQTtBQUFOO0FBR1E7RUFDRSxrQkFBQTtFQUNBLFVBQUE7QUFEVjtBQUdVO0VBQ0Usa0JBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLFNBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0FBRFo7QUFHWTtFQUNFLFdBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxTQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLG9DQUFBO0FBRGQ7QUFLUTtFQUNFLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFVBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtBQUhWO0FBS1U7RUFDRSxzQkFBQTtBQUhaO0FBS1U7RUFDRSxzQkFBQTtBQUhaO0FBS1U7RUFDRSxzQkFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxTQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtBQUhaIiwiZmlsZSI6ImJvYXJkLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsic2VjdGlvbiB7XG4gICYgdWwge1xuICAgIGxpc3Qtc3R5bGUtdHlwZTogbm9uZTtcbiAgICBsaXN0LXN0eWxlLXBvc2l0aW9uOiBpbnNpZGU7XG4gICAgbWFyZ2luOiAwO1xuICAgIHBhZGRpbmc6IDA7XG4gICAgZGlzcGxheTogZmxleDtcblxuICAgICYgdWwge1xuICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG5cbiAgICAgICYgbGkge1xuICAgICAgICAmLmJvYXJkIHtcbiAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICAgICAgei1pbmRleDogMTtcblxuICAgICAgICAgICYgLmNlbGwge1xuICAgICAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgICAgICAgd2lkdGg6IDcwcHg7XG4gICAgICAgICAgICBoZWlnaHQ6IDcwcHg7XG4gICAgICAgICAgICBtYXJnaW46IDA7XG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICAgICAgICBvdmVyZmxvdzogaGlkZGVuO1xuXG4gICAgICAgICAgICAmOmFmdGVyIHtcbiAgICAgICAgICAgICAgY29udGVudDogXCJcIjtcbiAgICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgICBsZWZ0OiAxMHB4O1xuICAgICAgICAgICAgICB0b3A6IDEwcHg7XG4gICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgICAgICAgICAgICAgd2lkdGg6IDUwcHg7XG4gICAgICAgICAgICAgIGhlaWdodDogNTBweDtcbiAgICAgICAgICAgICAgYm94LXNoYWRvdzogMHB4IDBweCAwcHggNzBweCAjMDAzYjZmO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICAmLnRva2VuIHtcbiAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgei1pbmRleDogMDtcbiAgICAgICAgICBsZWZ0OiAxMHB4O1xuICAgICAgICAgIHdpZHRoOiA1MHB4O1xuICAgICAgICAgIGhlaWdodDogNTBweDtcblxuICAgICAgICAgICYucGxheWVyMSB7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmYwO1xuICAgICAgICAgIH1cbiAgICAgICAgICAmLnBsYXllcjIge1xuICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2YwMDtcbiAgICAgICAgICB9XG4gICAgICAgICAgJi53aW46YWZ0ZXIge1xuICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogIzAwMDtcbiAgICAgICAgICAgIGNvbnRlbnQ6IFwiXCI7XG4gICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICBsZWZ0OiAxN3B4O1xuICAgICAgICAgICAgdG9wOiAxN3B4O1xuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xuICAgICAgICAgICAgd2lkdGg6IDE2cHg7XG4gICAgICAgICAgICBoZWlnaHQ6IDE2cHg7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG59XG4iXX0= */"] });


/***/ }),

/***/ "+d1p":
/*!**********************************************************************!*\
  !*** ./src/app/components/connect-four/control/control.component.ts ***!
  \**********************************************************************/
/*! exports provided: ControlComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ControlComponent", function() { return ControlComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var src_app_models_player__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/models/player */ "NAel");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");




function ControlComponent_li_2_Template(rf, ctx) { if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "li");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "button", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ControlComponent_li_2_Template_button_click_1_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r4); const c_r2 = ctx.index; const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r3.buttonClicked(c_r2); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", ctx_r0.player === ctx_r0.player1 ? "player1" : "player2");
} }
class ControlComponent {
    constructor() {
        this.buttonClickedEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.player1 = src_app_models_player__WEBPACK_IMPORTED_MODULE_1__["TokenVals"].player1;
    }
    ngOnInit() {
        this.columns = new Array(this.boardWidth);
    }
    buttonClicked(buttonIndex) {
        this.buttonClickedEvent.emit(buttonIndex);
    }
}
ControlComponent.ɵfac = function ControlComponent_Factory(t) { return new (t || ControlComponent)(); };
ControlComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: ControlComponent, selectors: [["app-control"]], inputs: { boardWidth: "boardWidth", player: "player" }, outputs: { buttonClickedEvent: "buttonClickedEvent" }, decls: 3, vars: 1, consts: [[4, "ngFor", "ngForOf"], [3, "ngClass", "click"]], template: function ControlComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "section");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "ul");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, ControlComponent_li_2_Template, 2, 1, "li", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.columns);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["NgForOf"], _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgClass"]], styles: ["section[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%] {\n  list-style-type: none;\n  list-style-position: inside;\n  margin: 0;\n  padding: 0;\n  display: flex;\n}\nsection[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   button[_ngcontent-%COMP%] {\n  width: 50px;\n  height: 50px;\n  margin: 10px 10px 2px 10px;\n  border: 0 none;\n  border-radius: 50%;\n  background-color: transparent;\n}\nsection[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:hover {\n  cursor: pointer;\n  background-color: #eee;\n}\nsection[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   button.player1[_ngcontent-%COMP%]:hover {\n  background-color: #ff0;\n}\nsection[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   button.player2[_ngcontent-%COMP%]:hover {\n  background-color: #f00;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL2NvbnRyb2wuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0U7RUFDRSxxQkFBQTtFQUNBLDJCQUFBO0VBQ0EsU0FBQTtFQUNBLFVBQUE7RUFDQSxhQUFBO0FBQUo7QUFFSTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsMEJBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSw2QkFBQTtBQUFOO0FBRU07RUFDRSxlQUFBO0VBQ0Esc0JBQUE7QUFBUjtBQUdNO0VBQ0Usc0JBQUE7QUFEUjtBQUdNO0VBQ0Usc0JBQUE7QUFEUiIsImZpbGUiOiJjb250cm9sLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsic2VjdGlvbiB7XG4gICYgdWwge1xuICAgIGxpc3Qtc3R5bGUtdHlwZTogbm9uZTtcbiAgICBsaXN0LXN0eWxlLXBvc2l0aW9uOiBpbnNpZGU7XG4gICAgbWFyZ2luOiAwO1xuICAgIHBhZGRpbmc6IDA7XG4gICAgZGlzcGxheTogZmxleDtcblxuICAgICYgYnV0dG9uIHtcbiAgICAgIHdpZHRoOiA1MHB4O1xuICAgICAgaGVpZ2h0OiA1MHB4O1xuICAgICAgbWFyZ2luOiAxMHB4IDEwcHggMnB4IDEwcHg7XG4gICAgICBib3JkZXI6IDAgbm9uZTtcbiAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgICAgIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xuXG4gICAgICAmOmhvdmVyIHtcbiAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZWVlO1xuICAgICAgfVxuXG4gICAgICAmLnBsYXllcjE6aG92ZXIge1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmYwO1xuICAgICAgfVxuICAgICAgJi5wbGF5ZXIyOmhvdmVyIHtcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2YwMDtcbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cbiJdfQ== */"] });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /Users/brianlbrinker/Documents/projects_personal/coding/ConnectFour/ConnectFour/connect-four/src/main.ts */"zUnb");


/***/ }),

/***/ "AytR":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "NAel":
/*!**********************************!*\
  !*** ./src/app/models/player.ts ***!
  \**********************************/
/*! exports provided: TokenVals */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TokenVals", function() { return TokenVals; });
var TokenVals;
(function (TokenVals) {
    TokenVals["unclaimed"] = "-";
    TokenVals["player1"] = "Player 1";
    TokenVals["player2"] = "Player 2";
})(TokenVals || (TokenVals = {}));


/***/ }),

/***/ "Sy1n":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "tyNb");


class AppComponent {
    constructor() {
        this.title = 'connect-four';
    }
}
AppComponent.ɵfac = function AppComponent_Factory(t) { return new (t || AppComponent)(); };
AppComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: AppComponent, selectors: [["app-root"]], decls: 1, vars: 0, template: function AppComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "router-outlet");
    } }, directives: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterOutlet"]], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhcHAuY29tcG9uZW50LnNjc3MifQ== */"] });


/***/ }),

/***/ "TkwQ":
/*!*******************************************************************!*\
  !*** ./src/app/components/connect-four/connect-four.component.ts ***!
  \*******************************************************************/
/*! exports provided: ConnectFourComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ConnectFourComponent", function() { return ConnectFourComponent; });
/* harmony import */ var src_app_models_player__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/models/player */ "NAel");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _control_control_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./control/control.component */ "+d1p");
/* harmony import */ var _board_board_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./board/board.component */ "+Xw4");





function ConnectFourComponent_span_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"]("", ctx_r0.currentPlayer, " wins!");
} }
class ConnectFourComponent {
    constructor() {
        this.boardWidth = 7;
        this.boardHeight = 6;
        this.connectionLength = 4;
        this.gameOver = false;
    }
    ngOnInit() {
        this.initTokenGrid(this.boardWidth, this.boardHeight);
        this.initPlayers();
    }
    initTokenGrid(width, height) {
        this.tokenGrid = new Array(height)
            .fill(src_app_models_player__WEBPACK_IMPORTED_MODULE_0__["TokenVals"].unclaimed)
            .map(() => new Array(width).fill(src_app_models_player__WEBPACK_IMPORTED_MODULE_0__["TokenVals"].unclaimed));
    }
    initPlayers() {
        this.currentPlayer = src_app_models_player__WEBPACK_IMPORTED_MODULE_0__["TokenVals"].player1;
    }
    togglePlayers() {
        if (this.currentPlayer === src_app_models_player__WEBPACK_IMPORTED_MODULE_0__["TokenVals"].player1) {
            this.currentPlayer = src_app_models_player__WEBPACK_IMPORTED_MODULE_0__["TokenVals"].player2;
        }
        else {
            this.currentPlayer = src_app_models_player__WEBPACK_IMPORTED_MODULE_0__["TokenVals"].player1;
        }
    }
    testHorizontalsFrom(rowIndex, colIndex, grid, player) {
        let nodes = [];
        for (let i = 0; i < this.connectionLength; i += 1) {
            nodes.push(grid[rowIndex][colIndex + i]);
        }
        return nodes.every(node => node === player);
    }
    testVerticalsFrom(rowIndex, colIndex, grid, player) {
        let nodes = [];
        for (let i = 0; i < this.connectionLength; i += 1) {
            nodes.push(grid[rowIndex - i][colIndex]);
        }
        return nodes.every(node => node === player);
    }
    testBkwdDiagsFrom(rowIndex, colIndex, grid, player) {
        let nodes = [];
        for (let i = 0; i < this.connectionLength; i += 1) {
            nodes.push(grid[rowIndex - i][colIndex - i]);
        }
        return nodes.every(node => node === player);
    }
    testFrwdDiagsFrom(rowIndex, colIndex, grid, player) {
        let nodes = [];
        for (let i = 0; i < this.connectionLength; i += 1) {
            nodes.push(grid[rowIndex - i][colIndex + i]);
        }
        return nodes.every(node => node === player);
    }
    playerWins(player, grid) {
        const topRow = this.boardHeight - this.connectionLength + 1;
        const rightCol = this.boardWidth - this.connectionLength + 1;
        const leftCol = this.connectionLength - 1;
        for (let rowIndex = this.boardHeight - 1; rowIndex >= 0; rowIndex -= 1) {
            for (let colIndex = 0; colIndex < this.boardWidth; colIndex += 1) {
                if (colIndex < rightCol) {
                    if (this.testHorizontalsFrom(rowIndex, colIndex, grid, player)) {
                        return true;
                    }
                }
                if (rowIndex > topRow) {
                    if (this.testVerticalsFrom(rowIndex, colIndex, grid, player)) {
                        return true;
                    }
                }
                if (rowIndex > topRow && colIndex < rightCol) {
                    if (this.testFrwdDiagsFrom(rowIndex, colIndex, grid, player)) {
                        return true;
                    }
                }
                if (rowIndex > topRow && colIndex > leftCol) {
                    if (this.testBkwdDiagsFrom(rowIndex, colIndex, grid, player)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    depositTokenAt(index, player) {
        for (let rowIndex = this.boardHeight - 1; rowIndex >= 0; rowIndex -= 1) {
            if (this.tokenGrid[rowIndex][index] === src_app_models_player__WEBPACK_IMPORTED_MODULE_0__["TokenVals"].unclaimed) {
                this.tokenGrid[rowIndex][index] = this.currentPlayer;
                break;
            }
        }
        if (!this.playerWins(this.currentPlayer, this.tokenGrid)) {
            this.togglePlayers();
        }
        else {
            this.gameOver = true;
        }
    }
    registerClick(index) {
        if (!this.gameOver) {
            this.depositTokenAt(index, this.currentPlayer);
        }
    }
}
ConnectFourComponent.ɵfac = function ConnectFourComponent_Factory(t) { return new (t || ConnectFourComponent)(); };
ConnectFourComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: ConnectFourComponent, selectors: [["app-connect-four"]], decls: 11, vars: 8, consts: [[1, "connect"], [4, "ngIf"], [1, "control"], [3, "boardWidth", "player", "buttonClickedEvent"], [1, "board"], [3, "boardWidth", "boardHeight", "tokenGrid"]], template: function ConnectFourComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "h1");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](4, ConnectFourComponent_span_4_Template, 2, 1, "span", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "section", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](8, "app-control", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("buttonClickedEvent", function ConnectFourComponent_Template_app_control_buttonClickedEvent_8_listener($event) { return ctx.registerClick($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](9, "section", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](10, "app-board", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"]("Connect ", ctx.connectionLength, "");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.gameOver);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"]("Turn: ", ctx.currentPlayer, "");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("boardWidth", ctx.boardWidth)("player", ctx.currentPlayer);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("boardWidth", ctx.boardWidth)("boardHeight", ctx.boardHeight)("tokenGrid", ctx.tokenGrid);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], _control_control_component__WEBPACK_IMPORTED_MODULE_3__["ControlComponent"], _board_board_component__WEBPACK_IMPORTED_MODULE_4__["BoardComponent"]], styles: ["div.connect[_ngcontent-%COMP%] {\n  font-family: Tahoma, Arial, sans-serif;\n}\ndiv.connect[_ngcontent-%COMP%]   h1[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n}\ndiv.connect[_ngcontent-%COMP%]   section[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: center;\n}\ndiv.connect[_ngcontent-%COMP%]   section.board[_ngcontent-%COMP%] {\n  left: calc(50% - 245px);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL2Nvbm5lY3QtZm91ci5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHNDQUFBO0FBQ0Y7QUFDRTtFQUNFLGFBQUE7RUFDQSw4QkFBQTtBQUNKO0FBS0U7RUFDRSxhQUFBO0VBQ0EsdUJBQUE7QUFISjtBQU9JO0VBQ0UsdUJBQUE7QUFMTiIsImZpbGUiOiJjb25uZWN0LWZvdXIuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJkaXYuY29ubmVjdCB7XG4gIGZvbnQtZmFtaWx5OiBUYWhvbWEsIEFyaWFsLCBzYW5zLXNlcmlmO1xuXG4gICYgaDEge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuXG4gICAgJiBzcGFuIHtcbiAgICB9XG4gIH1cblxuICAmIHNlY3Rpb24ge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG5cbiAgICAmLmNvbnRyb2wge1xuICAgIH1cbiAgICAmLmJvYXJkIHtcbiAgICAgIGxlZnQ6IGNhbGMoNTAlIC0gMjQ1cHgpO1xuICAgIH1cbiAgfVxufVxuIl19 */"] });


/***/ }),

/***/ "ZAI4":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser */ "jhN1");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app-routing.module */ "vY5A");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app.component */ "Sy1n");
/* harmony import */ var _components_connect_four_connect_four_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/connect-four/connect-four.component */ "TkwQ");
/* harmony import */ var _components_connect_four_board_board_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/connect-four/board/board.component */ "+Xw4");
/* harmony import */ var _components_connect_four_control_control_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./components/connect-four/control/control.component */ "+d1p");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ "fXoL");







class AppModule {
}
AppModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineNgModule"]({ type: AppModule, bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_2__["AppComponent"]] });
AppModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineInjector"]({ factory: function AppModule_Factory(t) { return new (t || AppModule)(); }, providers: [], imports: [[_angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"], _app_routing_module__WEBPACK_IMPORTED_MODULE_1__["AppRoutingModule"]]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵsetNgModuleScope"](AppModule, { declarations: [_app_component__WEBPACK_IMPORTED_MODULE_2__["AppComponent"],
        _components_connect_four_connect_four_component__WEBPACK_IMPORTED_MODULE_3__["ConnectFourComponent"],
        _components_connect_four_board_board_component__WEBPACK_IMPORTED_MODULE_4__["BoardComponent"],
        _components_connect_four_control_control_component__WEBPACK_IMPORTED_MODULE_5__["ControlComponent"]], imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"], _app_routing_module__WEBPACK_IMPORTED_MODULE_1__["AppRoutingModule"]] }); })();


/***/ }),

/***/ "vY5A":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _components_connect_four_connect_four_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./components/connect-four/connect-four.component */ "TkwQ");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");




const routes = [
    { path: "connect-four", component: _components_connect_four_connect_four_component__WEBPACK_IMPORTED_MODULE_1__["ConnectFourComponent"] },
    { path: "", redirectTo: "/connect-four", pathMatch: "full" }
];
class AppRoutingModule {
}
AppRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: AppRoutingModule });
AppRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ factory: function AppRoutingModule_Factory(t) { return new (t || AppRoutingModule)(); }, imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forRoot(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](AppRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] }); })();


/***/ }),

/***/ "zUnb":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser */ "jhN1");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "ZAI4");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "AytR");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["enableProdMode"])();
}
_angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["platformBrowser"]().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(err => console.error(err));


/***/ }),

/***/ "zn8P":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "zn8P";

/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map